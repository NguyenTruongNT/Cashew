import 'package:flutter/material.dart';

// =====================================================================
// [KIẾN TRÚC CASHEW - TẦNG HỆ THỐNG GIAO DIỆN & MÀU SẮC (THEME & COLORS)]
// File: lib/colors.dart
// Mô tả: Định nghĩa bảng màu chuẩn, phong cách phẳng (Flat/Material 3),
// hỗ trợ Light Mode và Dark Mode đồng bộ toàn ứng dụng theo phong cách Cashew.
// =====================================================================

class AppColors {
  // Màu sắc chủ đạo (Primary & Accent)
  static const Color primary = Color(0xFF1E88E5); // Xanh dương tri thức
  static const Color primaryDark = Color(0xFF1565C0);
  static const Color accent = Color(0xFF00ACC1); // Xanh cyan điểm nhấn

  // Màu sắc phân loại tài liệu (Document Type Colors)
  static const Color lectureColor = Color(0xFF43A047);     // Xanh lá: Bài giảng
  static const Color assignmentColor = Color(0xFFFB8C00);  // Cam: Bài tập
  static const Color referenceColor = Color(0xFF8E24AA);   // Tím: Tài liệu tham khảo
  static const Color examColor = Color(0xFFE53935);        // Đỏ: Đề thi / Kiểm tra

  // Màu nền và bề mặt (Light Theme)
  static const Color backgroundLight = Color(0xFFF8F9FA);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color cardLight = Color(0xFFFFFFFF);
  static const Color textLight = Color(0xFF212121);
  static const Color subtextLight = Color(0xFF757575);
  static const Color borderLight = Color(0xFFE0E0E0);

  // Màu nền và bề mặt (Dark Theme)
  static const Color backgroundDark = Color(0xFF121212);
  static const Color surfaceDark = Color(0xFF1E1E1E);
  static const Color cardDark = Color(0xFF252525);
  static const Color textDark = Color(0xFFEEEEEE);
  static const Color subtextDark = Color(0xFFAAAAAA);
  static const Color borderDark = Color(0xFF333333);

  // Trạng thái thông báo
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFF9800);
  static const Color error = Color(0xFFF44336);
  static const Color info = Color(0xFF2196F3);
}

/// Trả về ThemeData cho giao diện Sáng (Light Mode)
ThemeData getLightTheme() {
  final base = ThemeData.light(useMaterial3: true);
  return base.copyWith(
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: AppColors.backgroundLight,
    colorScheme: const ColorScheme.light(
      primary: AppColors.primary,
      secondary: AppColors.accent,
      surface: AppColors.surfaceLight,
      error: AppColors.error,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.surfaceLight,
      foregroundColor: AppColors.textLight,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: AppColors.textLight,
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.cardLight,
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColors.borderLight, width: 0.8),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.grey.shade50,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.borderLight),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.borderLight),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.primary, width: 2),
      ),
    ),
  );
}

/// Trả về ThemeData cho giao diện Tối (Dark Mode)
ThemeData getDarkTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: AppColors.backgroundDark,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.accent,
      surface: AppColors.surfaceDark,
      error: AppColors.error,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.surfaceDark,
      foregroundColor: AppColors.textDark,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: AppColors.textDark,
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.cardDark,
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColors.borderDark, width: 0.8),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF1E1E1E),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.borderDark),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.borderDark),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.primary, width: 2),
      ),
    ),
  );
}
