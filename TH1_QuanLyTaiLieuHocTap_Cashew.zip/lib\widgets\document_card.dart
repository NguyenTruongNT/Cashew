import 'package:flutter/material.dart';
import '../colors.dart';
import '../struct/formatters.dart';
import '../struct/models/document_models.dart';

// =====================================================================
// [KIẾN TRÚC CASHEW - TẦNG GIAO DIỆN TÁI SỬ DỤNG: THẺ TÀI LIỆU (DOCUMENT CARD)]
// File: lib/widgets/document_card.dart
// Mô tả: Widget thẻ hiển thị từng tài liệu học tập, bao gồm badge phân loại
// màu sắc, môn học, thời hạn nộp, trạng thái bài tập, nút yêu thích
// và menu tùy chọn hành động (Sửa, Xóa).
// =====================================================================

class DocumentCard extends StatelessWidget {
  final DocumentModel document;
  final SubjectModel? subject;
  final VoidCallback? onTap;
  final VoidCallback? onFavoriteToggle;
  final VoidCallback? onStatusToggle;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const DocumentCard({
    super.key,
    required this.document,
    this.subject,
    this.onTap,
    this.onFavoriteToggle,
    this.onStatusToggle,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final typeColor = document.type.color;
    final isAssignment = document.type == DocumentType.assignment;
    final isCompleted = document.status == DocumentStatus.completed;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isCompleted
              ? Colors.green.withOpacity(0.4)
              : AppColors.borderLight.withOpacity(0.8),
          width: isCompleted ? 1.5 : 1.0,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Hàng 1: Badge Phân loại & Môn học + Favorite + Menu
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Badge Loại tài liệu (Bài giảng / Bài tập / Tham khảo / Đề thi)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: typeColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(document.type.icon, size: 14, color: typeColor),
                        const SizedBox(width: 4),
                        Text(
                          document.type.displayName,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: typeColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),

                  // Mã môn học
                  if (subject != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: subject!.color.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        subject!.code,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: subject!.color,
                        ),
                      ),
                    ),

                  const Spacer(),

                  // Nút Yêu thích (Favorite)
                  IconButton(
                    iconSize: 20,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    icon: Icon(
                      document.isFavorite ? Icons.star_rounded : Icons.star_border_rounded,
                      color: document.isFavorite ? Colors.amber : Colors.grey,
                    ),
                    onPressed: onFavoriteToggle,
                    tooltip: 'Đánh dấu quan trọng',
                  ),
                  const SizedBox(width: 8),

                  // Menu 3 chấm (Sửa / Xóa)
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert_rounded, size: 20, color: Colors.grey),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    onSelected: (val) {
                      if (val == 'edit' && onEdit != null) onEdit!();
                      if (val == 'delete' && onDelete != null) onDelete!();
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit_outlined, size: 18),
                            SizedBox(width: 8),
                            Text('Chỉnh sửa'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete_outline_rounded, size: 18, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Xóa tài liệu', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // Tiêu đề tài liệu
              Text(
                document.title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  decoration: isCompleted ? TextDecoration.lineThrough : null,
                  color: isCompleted ? Colors.grey : null,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),

              // Ghi chú tóm tắt (nếu có)
              if (document.notes.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  document.notes,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],

              const SizedBox(height: 10),

              // Hàng cuối: Thông tin thời hạn, Thẻ Tags hoặc Nút hoàn thành
              Row(
                children: [
                  // Nếu là bài tập: Hiển thị Deadline và Checkbox trạng thái
                  if (isAssignment && document.deadline != null) ...[
                    Icon(
                      Icons.timer_outlined,
                      size: 14,
                      color: document.deadline!.isBefore(DateTime.now()) && !isCompleted
                          ? Colors.red
                          : Colors.grey.shade600,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      DocumentFormatters.formatRemainingTime(document.deadline),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: document.deadline!.isBefore(DateTime.now()) && !isCompleted
                            ? Colors.red
                            : Colors.grey.shade700,
                      ),
                    ),
                    const Spacer(),
                    // Nút bấm hoàn thành bài tập nhanh
                    InkWell(
                      onTap: onStatusToggle,
                      borderRadius: BorderRadius.circular(6),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: isCompleted
                              ? Colors.green.withOpacity(0.15)
                              : Colors.orange.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              isCompleted ? Icons.check_circle : Icons.radio_button_unchecked,
                              size: 14,
                              color: isCompleted ? Colors.green : Colors.orange,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              isCompleted ? 'Đã nộp bài' : 'Chưa nộp bài',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: isCompleted ? Colors.green : Colors.orange,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ] else ...[
                    // Nếu là tài liệu thông thường: Hiển thị ngày cập nhật và tags
                    Icon(Icons.calendar_today_outlined, size: 13, color: Colors.grey.shade500),
                    const SizedBox(width: 4),
                    Text(
                      DocumentFormatters.formatDate(document.updatedDate),
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                    const Spacer(),
                    if (document.fileUrl.isNotEmpty) ...[
                      Icon(Icons.link_rounded, size: 16, color: Theme.of(context).primaryColor),
                      const SizedBox(width: 4),
                      Text(
                        'Có liên kết',
                        style: TextStyle(
                          fontSize: 12,
                          color: Theme.of(context).primaryColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
