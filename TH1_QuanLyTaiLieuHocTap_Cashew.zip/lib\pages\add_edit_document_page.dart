import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../colors.dart';
import '../database/databaseGlobal.dart';
import '../functions.dart';
import '../struct/document_service.dart';
import '../struct/formatters.dart';
import '../struct/models/document_models.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/framework/page_framework.dart';

// =====================================================================
// [KIẾN TRÚC CASHEW - TẦNG GIAO DIỆN CHỨC NĂNG: THÊM & SỬA TÀI LIỆU]
// File: lib/pages/add_edit_document_page.dart
// Mô tả: Màn hình xử lý đồng thời chức năng THÊM MỚI (Create) và CHỈNH SỬA (Update)
// tài liệu học tập theo Checklist 3 của đề tài.
// =====================================================================

class AddEditDocumentPage extends StatefulWidget {
  final DocumentModel? initialDocument;
  final String? defaultSubjectId;

  const AddEditDocumentPage({
    super.key,
    this.initialDocument,
    this.defaultSubjectId,
  });

  @override
  State<AddEditDocumentPage> createState() => _AddEditDocumentPageState();
}

class _AddEditDocumentPageState extends State<AddEditDocumentPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _titleController;
  late final TextEditingController _notesController;
  late final TextEditingController _fileUrlController;
  late final TextEditingController _tagsController;

  late DocumentType _selectedType;
  late PriorityLevel _selectedPriority;
  late bool _isFavorite;
  String? _selectedSubjectId;
  DateTime? _selectedDeadline;
  List<SubjectModel> _availableSubjects = [];
  bool _isLoadingSubjects = true;

  bool get isEditing => widget.initialDocument != null;

  @override
  void initState() {
    super.initState();
    final doc = widget.initialDocument;

    _titleController = TextEditingController(text: doc?.title ?? '');
    _notesController = TextEditingController(text: doc?.notes ?? '');
    _fileUrlController = TextEditingController(text: doc?.fileUrl ?? '');
    _tagsController = TextEditingController(text: doc?.tags.join(', ') ?? '');

    _selectedType = doc?.type ?? DocumentType.lecture;
    _selectedPriority = doc?.priority ?? PriorityLevel.medium;
    _isFavorite = doc?.isFavorite ?? false;
    _selectedSubjectId = doc?.subjectId ?? widget.defaultSubjectId;
    _selectedDeadline = doc?.deadline;

    _loadSubjects();
  }

  Future<void> _loadSubjects() async {
    final list = await database.getAllSubjects();
    if (mounted) {
      setState(() {
        _availableSubjects = list;
        if (_selectedSubjectId == null && list.isNotEmpty) {
          _selectedSubjectId = list.first.id;
        }
        _isLoadingSubjects = false;
      });
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _notesController.dispose();
    _fileUrlController.dispose();
    _tagsController.dispose();
    super.dispose();
  }

  Future<void> _pickDeadline() async {
    final now = DateTime.now();
    final initial = _selectedDeadline ?? now.add(const Duration(days: 3));
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: initial.isBefore(now) ? now : initial,
      firstDate: now.subtract(const Duration(days: 365)),
      lastDate: now.add(const Duration(days: 365 * 3)),
    );

    if (pickedDate != null && mounted) {
      final pickedTime = await showTimePicker(
        context: context,
        initialTime: _selectedDeadline != null
            ? TimeOfDay.fromDateTime(_selectedDeadline!)
            : const TimeOfDay(hour: 23, minute: 59),
      );

      final combined = DateTime(
        pickedDate.year,
        pickedDate.month,
        pickedDate.day,
        pickedTime?.hour ?? 23,
        pickedTime?.minute ?? 59,
      );

      setState(() {
        _selectedDeadline = combined;
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedSubjectId == null) {
      openSnackbar(context, message: 'Vui lòng chọn môn học cho tài liệu!', isError: true);
      return;
    }

    final rawTags = _tagsController.text
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    try {
      if (isEditing) {
        // CẬP NHẬT TÀI LIỆU (Update)
        final updatedDoc = widget.initialDocument!.copyWith(
          title: _titleController.text.trim(),
          subjectId: _selectedSubjectId!,
          type: _selectedType,
          notes: _notesController.text.trim(),
          fileUrl: _fileUrlController.text.trim(),
          tags: rawTags,
          priority: _selectedPriority,
          isFavorite: _isFavorite,
          deadline: _selectedDeadline,
        );

        await DocumentService.updateDocument(updatedDoc);
        if (mounted) {
          openSnackbar(context, message: 'Đã cập nhật tài liệu thành công!');
          Navigator.pop(context, true);
        }
      } else {
        // TẠO MỚI TÀI LIỆU (Create)
        final newDoc = DocumentModel(
          id: const Uuid().v4(),
          title: _titleController.text.trim(),
          subjectId: _selectedSubjectId!,
          type: _selectedType,
          notes: _notesController.text.trim(),
          fileUrl: _fileUrlController.text.trim(),
          tags: rawTags,
          status: DocumentStatus.pending,
          priority: _selectedPriority,
          isFavorite: _isFavorite,
          deadline: _selectedDeadline,
          createdDate: DateTime.now(),
          updatedDate: DateTime.now(),
        );

        await DocumentService.saveDocument(newDoc);
        if (mounted) {
          openSnackbar(context, message: 'Đã thêm tài liệu học tập mới!');
          Navigator.pop(context, true);
        }
      }
    } catch (e) {
      if (mounted) {
        openSnackbar(context, message: 'Lỗi: ${e.toString()}', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFramework(
      title: isEditing ? 'Chỉnh sửa tài liệu' : 'Thêm tài liệu mới',
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: _save,
            icon: const Icon(Icons.check_rounded, size: 18),
            label: Text(isEditing ? 'Lưu' : 'Tạo mới'),
          ),
        ),
      ],
      body: _isLoadingSubjects
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Chọn Môn học
                  const Text('Môn học / Học phần *', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.borderLight),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: _selectedSubjectId,
                        items: _availableSubjects.map((s) {
                          return DropdownMenuItem<String>(
                            value: s.id,
                            child: Row(
                              children: [
                                Container(
                                  width: 12,
                                  height: 12,
                                  decoration: BoxDecoration(
                                    color: s.color,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Text('[${s.code}] ${s.name}', style: const TextStyle(fontSize: 14)),
                              ],
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          setState(() {
                            _selectedSubjectId = val;
                          });
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Phân loại tài liệu (Bài giảng / Bài tập / Tham khảo / Đề thi)
                  const Text('Phân loại tài liệu *', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: DocumentType.values.map((type) {
                      final isSelected = _selectedType == type;
                      return ChoiceChip(
                        label: Text(type.displayName),
                        selected: isSelected,
                        avatar: Icon(type.icon, size: 16, color: isSelected ? type.color : Colors.grey),
                        selectedColor: type.color.withOpacity(0.2),
                        labelStyle: TextStyle(
                          color: isSelected ? type.color : null,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                        side: BorderSide(color: isSelected ? type.color : Colors.grey.shade300),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        onSelected: (val) {
                          if (val) {
                            setState(() {
                              _selectedType = type;
                            });
                          }
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),

                  // Tiêu đề tài liệu
                  CustomTextField(
                    controller: _titleController,
                    label: 'Tiêu đề tài liệu *',
                    hint: 'Ví dụ: Bài tập lớn Kiến trúc Phần mềm Tuần 4',
                    prefixIcon: Icons.title_rounded,
                    validator: DocumentService.validateTitle,
                  ),

                  // Đường dẫn File đính kèm hoặc URL trực tuyến
                  CustomTextField(
                    controller: _fileUrlController,
                    label: 'Đường dẫn File / Liên kết học tập',
                    hint: 'Ví dụ: https://drive.google.com/... hoặc tài liệu.pdf',
                    prefixIcon: Icons.link_rounded,
                    validator: DocumentService.validateUrl,
                  ),

                  // Nếu là bài tập hoặc đề thi: Chọn Hạn nộp (Deadline)
                  if (_selectedType == DocumentType.assignment || _selectedType == DocumentType.exam) ...[
                    const Text('Thời hạn hoàn thành (Deadline)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(height: 6),
                    InkWell(
                      onTap: _pickDeadline,
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.borderLight),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.event_rounded, size: 20, color: Colors.grey),
                            const SizedBox(width: 8),
                            Text(
                              _selectedDeadline != null
                                  ? DocumentFormatters.formatDateTime(_selectedDeadline)
                                  : 'Chưa đặt hạn nộp (Bấm để chọn)',
                              style: TextStyle(
                                fontSize: 14,
                                color: _selectedDeadline != null ? Colors.black87 : Colors.grey.shade600,
                              ),
                            ),
                            const Spacer(),
                            if (_selectedDeadline != null)
                              IconButton(
                                icon: const Icon(Icons.clear_rounded, size: 18),
                                onPressed: () {
                                  setState(() {
                                    _selectedDeadline = null;
                                  });
                                },
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Thẻ phân loại (Tags)
                  CustomTextField(
                    controller: _tagsController,
                    label: 'Thẻ phân loại (Tags, phân cách bằng dấu phẩy)',
                    hint: 'Ví dụ: Slide, Chương 2, Đồ án, Nộp gấp',
                    prefixIcon: Icons.label_outline_rounded,
                  ),

                  // Mức độ ưu tiên
                  const Text('Mức độ ưu tiên', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 8),
                  SegmentedButton<PriorityLevel>(
                    segments: const [
                      ButtonSegment(value: PriorityLevel.low, label: Text('Thấp')),
                      ButtonSegment(value: PriorityLevel.medium, label: Text('Bình thường')),
                      ButtonSegment(value: PriorityLevel.high, label: Text('Cao / Gấp')),
                    ],
                    selected: {_selectedPriority},
                    onSelectionChanged: (set) {
                      setState(() {
                        _selectedPriority = set.first;
                      });
                    },
                  ),
                  const SizedBox(height: 16),

                  // Ghi chú tóm tắt
                  CustomTextField(
                    controller: _notesController,
                    label: 'Ghi chú & Tóm tắt nội dung',
                    hint: 'Ghi chú nội dung trọng tâm cần ghi nhớ...',
                    prefixIcon: Icons.notes_rounded,
                    maxLines: 4,
                  ),

                  // Đánh dấu yêu thích / Quan trọng
                  SwitchListTile(
                    title: const Text('Đánh dấu tài liệu quan trọng', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    subtitle: const Text('Ghim hoặc gắn sao để xem nhanh tại trang chủ'),
                    value: _isFavorite,
                    activeColor: Colors.amber,
                    onChanged: (val) {
                      setState(() {
                        _isFavorite = val;
                      });
                    },
                    secondary: Icon(
                      _isFavorite ? Icons.star_rounded : Icons.star_border_rounded,
                      color: _isFavorite ? Colors.amber : Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
    );
  }
}
